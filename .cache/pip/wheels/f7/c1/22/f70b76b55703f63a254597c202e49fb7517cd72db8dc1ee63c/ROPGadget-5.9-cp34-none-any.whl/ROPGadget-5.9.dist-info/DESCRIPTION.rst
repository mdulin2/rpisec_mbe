ROPgadget supports ELF, PE and Mach-O format on x86, x64, ARM, ARM64, PowerPC, SPARC and MIPS architectures.
http://www.shell-storm.org/project/ROPgadget/
Home-page: https://github.com/JonathanSalwan/ROPgadget
Author: Jonathan Salwan
Author-email: jonathan.salwan@gmail.com
License: BSD
Description: UNKNOWN
Platform: UNKNOWN
Classifier: Topic :: Security
Classifier: Environment :: Console
Classifier: Operating System :: OS Independent
Classifier: License :: OSI Approved :: BSD License
Classifier: Programming Language :: Python :: 2.7
Classifier: Intended Audience :: Developers
